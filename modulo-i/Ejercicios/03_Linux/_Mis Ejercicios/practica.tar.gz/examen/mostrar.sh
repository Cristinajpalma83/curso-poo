#/bin/bash
cat ~/examen/documentos/personal/fichero1.txt
