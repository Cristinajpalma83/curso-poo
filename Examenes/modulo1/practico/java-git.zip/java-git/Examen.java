//Solicitar listado de notas de los alumnos al usuario
//El usuario ingresará nota negativa para finalizar la carga
//Suspensos < 5
// 5 <= Suficientes y bien < 9
// 9 <= Sobressaliente <= 10
// Media de las notas: suma / cant. notas

import java.util.Scanner;
public class Examen{
    public static void main (String[] arg){
        Scanner tec = new Scanner(System.in);
        double n, suma; 
        int cant, insuf, suf, sobre;
        suma = cant = insuf = suf = sobre = 0;

        System.out.println("""
                        Ingrese listado de notas:
                            0 - 5 : Insuficiente
                            5 - 8 : Suficiente y Bien
                            9 - 10: Sobresaliente

                        Para salir: ingrese un número negativo
                        * Las notas mayores a 10 no se contabilizarán
                        """);

        do {
            n = tec.nextDouble();            

            if (n >= 0) {
                if (n < 5) insuf++;
                if (n >= 5 && n <9) suf++;
                if (n >= 9 && n <= 10) sobre++;

                suma = suma + n;
                cant++;
            }            
        } while (n >= 0);

        System.out.println("Suspensos: " + insuf);
        System.out.println("Suficientes y bienes: " + suf);
        System.out.println("Sobresalientes: " + sobre);
        System.out.println("Media de notas: " + suma / cant);
    }
}